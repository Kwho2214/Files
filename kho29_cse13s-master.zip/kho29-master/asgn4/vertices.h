#pragma once

#define START_VERTEX 0
#define VERTICES     26
