This program is to help Professor Long's father, Denver Long, to find an optimal route to all the cities along his way and get him home. In this program we use DFS(Depth first search) to find the shortest hamiltonian path. A hamiltonian path is a path where we visit each vertex only once in a graph. 

To build program:
Download all files needed.
In linux terminal type make to create tsp

To run program:
Type ./tsp in linux terminal

Command line options:
-h prints help message
-v verbose printing
-u uses undirected graph
-i specifies the input file
-o specifies the output file
