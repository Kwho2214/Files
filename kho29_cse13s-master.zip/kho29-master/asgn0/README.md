Assignment 0 - Hello World!

This program prints out "Hello World!".

