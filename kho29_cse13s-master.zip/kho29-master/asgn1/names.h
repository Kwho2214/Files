#pragma once

const char *names[10] = {
    "Wilbur",
    "Charlotte",
    "John",
    "Fern",
    "Templeton",
    "Avery",
    "Homer",
    "Henry",
    "Dr. Dorian",
    "Aranea",
};
