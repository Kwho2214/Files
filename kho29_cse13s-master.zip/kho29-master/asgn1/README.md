This program is simulating the pig game. The game begins with the programm asking for the number of players that is between 2 and 10. If not in this range the programm defaults to 2 players. It then ask for the seed. If entered a invalid seed, default seed will be 2021. The rules of the game is, players rolls the pig, if pig lands back or trotter +10 points, snout is 15 points, and jowler gives 5 points. If the pig lands of side, no points and the player's turn ends. The game goes on until one player has 100 points or more. 

To build the programm:
download all files needed, then in the terminal, type "make" to make pig programm.

To run the program:
do ./pig and then enter the number of players in range of 2-10, and a seed.  
