#pragma once

#include "stats.h"

#include <stdint.h>

void shell_sort(Stats *stats, uint32_t *A, uint32_t n);
