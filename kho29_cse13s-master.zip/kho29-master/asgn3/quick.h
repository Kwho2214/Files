#pragma once

#include "stats.h"

#include <stdint.h>

void quick_sort(Stats *stats, uint32_t *A, uint32_t n);
