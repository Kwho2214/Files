# Notes

Your weekly notes should be submitted into this directory.
