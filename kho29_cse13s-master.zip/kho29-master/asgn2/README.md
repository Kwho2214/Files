This program is a small math library where we compute Euler's number and PI using Madhava formula, Euler's solution, the Bailey-Borwein-Plouffe Formula, Viete's formula. We wrote our own math programms and then compared it to math.h's e and PI. To run this programm, download the files that are needed. Run mathlib-test along with the options -"aebmvrsh". To learn what all the options do, do ./mathlib-test -h to see the full details.


