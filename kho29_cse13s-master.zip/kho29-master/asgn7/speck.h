#pragma once

#include <stdint.h>

uint32_t hash(uint64_t *salt, char *key);
